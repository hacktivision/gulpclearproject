const projectName = require('path').basename(__dirname);
const sourseDir = '#src';
const projectDir = 'dist';

const path = {
    build: {
		html: projectDir + `/`,
		css: projectDir + `/css/`,
		js: projectDir +  `/js/`,
		img: projectDir + `/img/`,
		fonts: projectDir + `/fonts/`,
		libs: projectDir + `/libs/`,
	},
	sourse: {
		html: sourseDir + `/html/[^_]*.html`,
		scss: sourseDir + `/scss/main.scss`,
		js: sourseDir + `/js/main.js`,
		img: sourseDir + `/img/**/*.{jpg,png,svg,gif,ico,webp}`,
		fonts: sourseDir + `/fonts/*.ttf`,
		libs: sourseDir + `/libs/**/*`,
	},
	watch: {
		html: sourseDir + `/**/*.html`,
		scss: sourseDir + `/scss/**/*.scss`,
		js: sourseDir + `/js/**/*.js`,
		img: sourseDir + `/img/**/*.{jpg,png,svg,gif,ico,webp}`,
	},
	clean: projectDir + `/`
}


const {src, dest} = require('gulp'),
	gulp = require('gulp'),
	scss = require('gulp-sass'),
	browsersync = require('browser-sync').create(),
	fileinclude = require('gulp-file-include'),
	autoprefixer = require('gulp-autoprefixer'),
	groupmedia = require('gulp-group-css-media-queries'),
	cleancss = require('gulp-clean-css'),
	rename = require('gulp-rename'),
	uglify = require('gulp-uglify-es').default,
	babel = require('gulp-babel'),
	imagemin = require('gulp-imagemin'),
	webp = require('gulp-webp'),
	webphtml = require('gulp-webp-html'),
	svgsprite = require('gulp-svg-sprite'),
	ttf2woff = require('gulp-ttf2woff'),
	ttf2woff2 = require('gulp-ttf2woff2'),
	fonter = require('gulp-fonter'),
	zip = require('gulp-zip'),
	// sourcemaps = require('gulp-sourcemaps'),
	// mocha = require('gulp-mocha'),
	// concat = require('gulp-concat'),
	// filter = require('gulp-filter'),
	// gulpif = require('gulp-if'),
	del = require('del'),
	resizeImg = require('resize-img');

const fs = require('fs');

const browserSync = () => {
    browsersync.init({
        server: {
			baseDir: projectDir + `/`,
		},
		port: 3000,
		notify: false
    })
}

// Html
const html = () =>{
    return src(path.sourse.html)
		.pipe(fileinclude())
		// .pipe(webphtml())
        .pipe(dest(path.build.html))
        .pipe(browsersync.stream());
}

// Css
const css = () => {
    return src(path.sourse.scss)
        .pipe(scss({
			outputStyle: 'expanded'
		}))
		.pipe(groupmedia())
		.pipe(autoprefixer(["last 15 version", "> 1%", "ie 9", "ie 8", "ie 7"], { cascade: true }))
		.pipe(dest(path.build.css))
		.pipe(browsersync.stream())
		.pipe(cleancss())
		.pipe(rename({extname: '.min.css'}))
		.pipe(dest(path.build.css))
		.pipe(browsersync.stream())
}

// Js
const js = () => {
    return src(path.sourse.js)
        .pipe(fileinclude())
		.pipe(babel({
			presets: ['@babel/env']
		}))
		.pipe(dest(path.build.js))
		.pipe(uglify())
		.pipe(rename({extname: '.min.js'}))
		.pipe(dest(path.build.js))
		.pipe(browsersync.stream())
}

// Images
const images = () => {
	return src(path.sourse.img)
		.pipe(webp({
			quality: 70
		}))
		.pipe(dest(path.build.img))
		.pipe(src(path.sourse.img))
		.pipe(imagemin({
			progressive: true,
			svgoPlugins: [{ removeViewBox: false }],
			interlaced: true,
			optimizationLevel: 3
		}))
		.pipe(dest(path.build.img))
		.pipe(browsersync.stream())
}

// Libs
const libs = () => {
	return src(path.sourse.libs)
		.pipe(dest(path.build.libs));
}

// Fonts
const fonts = () => {
	src(path.sourse.fonts)
		.pipe(ttf2woff())
		.pipe(dest(path.build.fonts));
	return src(path.sourse.fonts)
		.pipe(ttf2woff2())
		.pipe(dest(path.build.fonts));
}

// Clear
const clean = () => {
	return del(path.clean)
}

// Font style
const fontsStyle = () => {
	let file_content = fs.readFileSync(sourseDir + "/scss/base/_fonts.scss");
	if (file_content == "") {
		fs.writeFile(sourseDir + "/scss/base/_fonts.scss",file_content , ()=>{});
		return fs.readdir(path.build.fonts, function (err, items) {
			if (items) {
				let c_fontname;
				for (var i = 0; i < items.length; i++) {
					let fontname = items[i].split(".");
					fontname = fontname[0];
					if (c_fontname != fontname) {
						fs.appendFile( sourseDir + "/scss/base/_fonts.scss", '@include font("' + fontname + '", "' + fontname + '", "400", "normal");\r\n', ()=>{} );
					}
					c_fontname = fontname;
				}
			}
		});
	}
}


// Otf to ttf
gulp.task('otf2ttf', () => {
	return src([`.//fonts/*.otf`])
		.pipe(fonter({
			formats: ['ttf']
		}))
		.pipe(dest(`.//fonts/`));
});

// Svg icon
gulp.task('svgSprite', () => {
	return gulp.src([`./iconsprite/*.svg`])
		.pipe(svgsprite({
			mode: {
				stack: {
					sprite: '../icons/icons.svg',
					example: true
				}
			}
		}))
		.pipe(dest('./app/img/'))
});

// Favicons sizes
const favicons = {
	'apple-touch-icon': [57, 60, 72, 76, 114, 120, 144, 152, 180],
	'android-icon': [192],
	'favicon': [32, 96, 16]
};
gulp.task('favicon-resize', () => {
	for (let i in favicons) {
		for (let j of favicons[i]) {
			resizeImg(fs.readFileSync('./#src/img/common/favicon.png'), { width: j, height: j }).then(buf => {
				fs.writeFileSync(`./#src/img/common/${i}-${j}x${j}.png`, buf)
			})
		}
	}
	return true;
});

// To archive
gulp.task('zip', () => {
	gulp.src('./#src/*')
		.pipe(zip(projectName + '.zip'))
		.pipe(dest('./'))
})


const watching = () => {
    gulp.watch([path.watch.html], html);
    gulp.watch([path.watch.scss], css);
    gulp.watch([path.watch.js], js);
    gulp.watch([path.watch.img], images);
}

const build = gulp.series(clean, gulp.parallel(css, js, html, images, libs));
const watch = gulp.parallel(build, browserSync, watching);

exports.libs = libs;
// exports.fontsStyle = fontsStyle;
// exports.fonts = fonts;
exports.images = images;
exports.js = js;
exports.css = css;
exports.html = html;
exports.build = build;
exports.watch = watch;
exports.default = watch;